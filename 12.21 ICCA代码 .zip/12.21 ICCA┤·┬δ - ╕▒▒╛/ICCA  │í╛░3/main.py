from generate_nodes import generate_nodes
from modify_communication_nodes import modify_communication_nodes
import pickle
import numpy as np
import time
import test
import jammer_run
import jammer_first_run
# 导入 test.py 模块
#1.运行main，将生成的通信节点信息和干扰机信息（无剩余功率）保存到文件中（layout_result 和 nodes_first），表示未更新的干扰机信息。
# 2.运行jammer_first_run，第一次计算干扰机的剩余功率，将更新后的 干扰机信息 保存到文件updated_layout_result中
#3.回到main，将updated_layout_result覆盖在layout_result中。
# 4.运行main，启动test，以新的干扰机信息和通信节点信息（layout_result和communication），进行测试，判断干扰是否符合干信比为3的要求。

np.random.seed(40) #固定随机数种子，确保每次运行结果一致



def save_layout_result(layout_result, nodes_first):
    """
    将 layout_result 和 nodes_first 保存到文件中。
    """
    # 保存 layout_result
    with open("layout_result.pkl", "wb") as f:  #含干扰机剩余能量
        pickle.dump(layout_result, f)

    # 保存 nodes_first
    with open("nodes_first.pkl", "wb") as f:
        pickle.dump(nodes_first, f)

    print("layout_result 和 nodes_first 已保存到文件中。")



def load_layout_result():
    """
    从文件中加载更新后的 updated_layout_result。
    """
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
    return layout_result

def load_nodes_first():
    """
    从文件中加载更新后的 nodes_first。
    """
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)
    return nodes_first


def main():

    nodes_first = [
        [1, 1, 25800, 44600, 2900, -109, -91.39],
        [2, 1, 1600, 9400, 2000, -114, -89.38],
        [3, 1, 26700, 20000, 2400, -112, -92.75],
        [4, 1, 18000, 36000, 2600, -112, -91.98],
        [5, 1, 26900, 100, 2500, -112, -91.92],
        [6, 1, 20000, 40700, 2000, -110, -93.8],
        [7, 1, 27900, 34900, 2100, -109, -89.23],
        [8, 1, 44600, 5300, 2800, -113, -95.38],
        [9, 1, 5900, 34100, 2600, -110, -90.6],
        [10, 1, 13500, 6600, 2700, -111, -91.23],
        [11, 1, 35800, 6800, 2600, -105, -88.59],
        [12, 1, 13100, 38600, 2100, -113, -97.12],
        [13, 1, 32300, 29000, 2500, -114, -90.17],
        [14, 1, 32400, 6000, 2000, -107, -89.34],
        [15, 1, 38000, 22800, 2600, -113, -95.04],
        [16, 2, 16300, 31800, 10, -98, -82.1],
        [17, 2, 21400, 800, 10, -104, -86.19],
        [18, 2, 23000, 48400, 10, -105, -89.47],
        [19, 2, 10500, 31700, 10, -102, -84.92],
        [20, 2, 30200, 32100, 10, -103, -87.87],
        [21, 2, 22800, 14300, 10, -101, -82.42],
        [22, 2, 31400, 21500, 10, -99, -86.72],
        [23, 2, 44000, 22900, 10, -102, -84.8],
        [24, 2, 8800, 11300, 10, -97, -81.44],
        [25, 2, 26400, 25900, 10, -98, -86.72],
        [26, 2, 25600, 40600, 10, -102, -89.47],
        [27, 2, 5200, 13900, 10, -100, -81.44],
        [28, 2, 20900, 32600, 10, -100, -82.1],
        [29, 2, 2600, 32100, 10, -100, -88.97],
        [30, 2, 600, 5800, 10, -104, -91.1],
        [31, 2, 30500, 2800, 10, -104, -91.1],
        [32, 2, 38800, 7200, 10, -95, -91.21],
        [33, 2, 15400, 3000, 10, -99, -86.19],
        [34, 2, 48900, 25900, 10, -103, -84.8],
        [35, 2, 21900, 9600, 10, -105, -82.42],
    ]

    #序号、类别、x、y、z、环境噪声、最大通信接收功率
    # 将第7列内容全部换算成1，表示频段为1
    for node in nodes_first:
        node[6] = 1  # 第7列表示频段，设置为1

    # 调用 generate_nodes 函数，生成初始的通信节点信息
    nodes_first = generate_nodes(nodes_first)

    print('nodes_first',nodes_first)


    # 定义 layout_result，干扰机位置
    layout_result = [
        [1, 0, 28000, 45000, 3, -99],
        [2, 0, 1900, 9800, 3, -96],
        [3, 0, 6200, 12500, 3, -95],
        [4, 0, 18300, 38500, 3, -101],
        [5, 0, 30300, 800, 3, -103],
        [6, 0, 14300, 39200, 3, -100],
        [7, 0, 31200, 30900, 3, -97],
        [8, 0, 42900, 6200, 3, -98],
        [9, 0, 6300, 32800, 3, -95],
        [10, 0, 12200, 7900, 3, -102],
        [11, 0, 34500, 6900, 3, -104],
        [12, 0, 30500, 4900, 3, -102],
        [13, 0, 31700, 27200, 3, -98],
        [14, 0, 39100, 23200, 3, -95],
        [15, 0, 20000, 10000, 3, -101],
        [16, 0, 16600, 30900, 3, -99],
        [17, 0, 21100, 1500, 3, -95],
        [18, 0, 22700, 47200, 3, -98],
        [19, 0, 10900, 30800, 3, -100],
        [20, 0, 41500, 22200, 3, -100],
        [21, 0, 24500, 13500, 3, -99],
        [22, 0, 31800, 22600, 3, -99],
        [23, 0, 43700, 23600, 3, -99],
        [24, 0, 25500, 16200, 3, -101],
        [25, 0, 26100, 27700, 3, -98],
        [26, 0, 25900, 41700, 3, -99],
        [27, 0, 18500, 33200, 3, -101],
        [28, 0, 21200, 31800, 3, -104],
        [29, 0, 2900, 31600, 3, -104],
        [30, 0, 900, 6100, 3, -95],
        [31, 1, 26100, 46400, 1200, -111],
        [32, 1, 1300, 8300, 1100, -108],
        [33, 1, 27100, 19200, 1300, -115],
        [34, 1, 17700, 35500, 1400, -110],
        [35, 1, 26600, 1200, 1000, -112],
        [36, 1, 19700, 41500, 1200, -105],
        [37, 1, 30500, 37300, 1100, -114],
        [38, 1, 45200, 4600, 1300, -107],
        [39, 1, 10300, 10500, 1000, -115],
        [40, 1, 37100, 8000, 1200, -112],
        [41, 1, 34600, 29700, 1300, -114],
        [42, 1, 47800, 24200, 1000, -110],
        [43, 0, 15200, 4800, 3, -104],
        [44, 0, 22900, 10600, 3, -104],
    ]
    #序号、类别、x、y、z、电磁环境噪声dBW

    # 保存 layout_result 和 nodes_first 到文件
    save_layout_result(layout_result, nodes_first)

    # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

    layout_result, elapsed_time = jammer_first_run.main_jammer_run()


    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中

    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中
    with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
        f.write(f"1次循环通信干扰决策\n")
        f.write(f"程序运行时长: {elapsed_time} 秒\n")
        f.write("layout_result数据:\n")
        for item in layout_result:
            f.write(f"{item}\n")

    # 加载第一次干扰更新后的 layout_result，干扰机序号、类型、x、y、z、功率w、剩余能量AH
    updated_layout_result = load_layout_result()
    #print("第一次更新后的 干扰机layout_result：", updated_layout_result,)



    #  将更新后的 updated_layout_result 保存到文件中 保存到 jammer.pkl 供 test.py 使用  ,不含干扰机剩余能量



    # 删除第 7、8 列数据（索引为 6、7）,对初始的通信节点nodes_first，处理，

    columns_to_delete = [6, 7]
    communication2 = np.delete(nodes_first, columns_to_delete, axis=1)
    # 将 communication2 转换为列表
    communication2 = communication2.tolist()

    print('communication2:')
    for row in communication2:
        print(row)

    # 将 communication2 保存到 communication.pkl 供 test.py 使用
    with open("communication.pkl", "wb") as f:
        pickle.dump(communication2, f)


    # 调用 test.py 的测试函数
    test_result = test.run_test(communication2, updated_layout_result)

    # 根据测试结果输出信息
    if test_result["success"]:
        print("第一次通信干扰成功！")

        # 依据成功干扰后的communication，生成新的通信信息，读取含剩余能量的layout_result,得到新的干扰机信息layout_result
        i = 2  # 初始化循环次数
        while True:
            communication = modify_communication_nodes()
            #print('功率调整后的通信方', communication)  # 序号、类型、x坐标、y坐标、z坐标、

            # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

            layout_result, elapsed_time = jammer_run.main_jammer_run()

            # 调用 test.py 的测试函数
            test_result = test.run_test(communication, layout_result)

            # 根据测试结果输出信息
            if test_result["success"]:
                print(f"第{i}次通信干扰成功！")
                # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,有用的次数减1
                with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                    f.write(f"{i}次循环通信干扰决策\n")
                    f.write(f"程序运行时长: {elapsed_time} 秒\n")
                    f.write("layout_result数据:\n")
                    for item in layout_result:
                        f.write(f"{item}\n")

                i += 1  # 循环次数加1

            else:
                print(f"第{i}次通信干扰失败！")
                print("以下通信节点达不到不符合干信比为3的干扰：")
                for warning in test_result["warnings"]:
                    print(warning)

                # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,保留最后失败的干扰数据，有用的次数减1
                with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                    f.write(f"{i}次循环通信干扰决策\n")
                    f.write(f"程序运行时长: {elapsed_time} 秒\n")
                    f.write("layout_result数据:\n")
                    for item in layout_result:
                        f.write(f"{item}\n")

                break  # 通信干扰失败，停止循环

        layout_result = load_layout_result()
        print("干扰失败后，最后更新后的 干扰机layout_result：", layout_result)
        print("干扰失败后，最后更新后的 communication：", communication)



    else:
        print("以下通信节点不符合干信比为3的干扰：")
        for warning in test_result["warnings"]:
            print(warning)





if __name__ == '__main__':
    for _ in range(1):  #程序运行30次
        main()