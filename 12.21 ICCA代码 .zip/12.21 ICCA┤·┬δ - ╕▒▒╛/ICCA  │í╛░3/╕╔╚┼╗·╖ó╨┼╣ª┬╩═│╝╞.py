import re
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
import chardet


# --------------------------
# 1. 自动检测文件编码（不变）
# --------------------------
def detect_file_encoding(file_path):
    with open(file_path, 'rb') as f:
        raw_data = f.read(10000)
        result = chardet.detect(raw_data)
        encoding = result['encoding'] if result['encoding'] else 'gbk'
        confidence = result['confidence']
        print(f"自动检测到文件编码：{encoding}（置信度：{confidence:.2f}）")
        return encoding


# --------------------------
# 2. 数据提取（不变，确保稳定获取循环与功率数据）
# --------------------------
def extract_power_data(file_path):
    # 读取文件（编码适配）
    encoding = detect_file_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            content = f.read()
        print(f"成功以 {encoding} 编码读取文件")
    except Exception as e:
        print(f"{encoding} 编码失败，重试 GBK：{str(e)}")
        with open(file_path, 'r', encoding='gbk', errors='ignore') as f:
            content = f.read()

    # 提取循环次数和layout数据块
    cycle_pattern = r'(\d+)次循环通信干扰决策'
    cycle_nums = list(map(int, re.findall(cycle_pattern, content)))
    layout_pattern = r'layout_result数据:(.*?)(?=chenggong:|(\d+)次循环通信干扰决策)'
    layout_blocks = re.findall(layout_pattern, content, re.DOTALL | re.IGNORECASE)
    layout_blocks_clean = [b[0] for b in layout_blocks if isinstance(b, tuple) and len(b) > 0]

    # 对齐循环次数与数据块数量
    min_len = min(len(cycle_nums), len(layout_blocks_clean))
    cycle_nums = cycle_nums[:min_len]
    layout_blocks_clean = layout_blocks_clean[:min_len]

    # 提取发信功率（倒数第2列）
    power_matrix = []
    for block in layout_blocks_clean:
        node_lines = re.findall(r'\[\s*([\d,\s\.-]+)\s*\]', block)
        power_per_cycle = []
        for line in node_lines:
            try:
                values = list(map(float, re.split(r',\s*', line.strip())))
                if len(values) >= 2:
                    power_per_cycle.append(values[-2])
            except ValueError:
                continue
        # 补全35个节点
        power_per_cycle = power_per_cycle[:35] + [np.nan] * (35 - len(power_per_cycle))
        power_matrix.append(power_per_cycle)

    return np.array(power_matrix), cycle_nums


# --------------------------
# 3. 数据预处理（不变）
# --------------------------
def preprocess_data(power_matrix):
    # 填充缺失值
    power_matrix_filled = np.copy(power_matrix)
    for i in range(power_matrix_filled.shape[0]):
        cycle_mean = np.nanmean(power_matrix_filled[i])
        power_matrix_filled[i] = np.where(np.isnan(power_matrix_filled[i]), cycle_mean, power_matrix_filled[i])
    # 标准化
    min_power = np.min(power_matrix_filled)
    max_power = np.max(power_matrix_filled)
    power_matrix_norm = (power_matrix_filled - min_power) / (max_power - min_power)
    return power_matrix_filled, power_matrix_norm, (min_power, max_power)


# --------------------------
# 4. 热力图可视化：核心优化数据与Y轴刻度方向对齐
# --------------------------
def plot_power_heatmap(power_matrix_filled, power_matrix_norm, cycle_nums, min_power, max_power):
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    fig, ax = plt.subplots(figsize=(14, 10))

    # 颜色映射（低→高：蓝→红）
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D']
    cmap = LinearSegmentedColormap.from_list('power_cmap', colors, N=256)

    # --------------------------
    # 核心优化1：反转数据矩阵行顺序
    # 效果：第1次循环数据（原矩阵第0行）→ 热力图底部行；最后1次循环数据→热力图顶部行
    # --------------------------
    power_matrix_norm_reversed = power_matrix_norm[::-1]  # 反转行顺序（关键！）
    power_matrix_filled_reversed = power_matrix_filled[::-1]  # 填充后的数据也同步反转（备用，不影响可视化）

    # --------------------------
    # 核心优化2：调整Y轴范围与刻度映射逻辑
    # 确保“Y轴底部=0（第1次循环），顶部=总循环数（最后1次循环）”
    # --------------------------
    max_cycle = len(cycle_nums)  # 实际总循环次数
    # 绘制热力图：extent参数Y轴范围改为“0 → max_cycle”，与反转后的数据对齐
    im = ax.imshow(
        power_matrix_norm_reversed,  # 使用反转后的数据
        cmap=cmap,
        aspect='auto',
        extent=[0.5, 35.5, 0, max_cycle]  # Y轴范围：底部=0（第1次循环），顶部=max_cycle（最后1次循环）
    )

    # 设置纵轴刻度：0,100,200...（自下向上递增，与数据顺序完全匹配）
    ax.set_ylabel('Number', fontsize=16, fontweight='bold')
    # 生成粗略刻度（0,100,200...不超过总循环数）
    rough_ticks = list(range(0, max_cycle + 100, 100))
    rough_ticks = [tick for tick in rough_ticks if tick <= max_cycle]  # 过滤超过总循环数的刻度
    # 刻度位置=刻度值（直接对应Y轴范围，无需反向映射！）
    ax.set_yticks(rough_ticks)
    ax.set_yticklabels([str(tick) for tick in rough_ticks], fontsize=10)

    # X轴：通信节点（不变，每2个显示一个刻度）
    ax.set_xlabel('Jammer Node Number', fontsize=16, fontweight='bold')
    ax.set_xticks(range(1, 36, 2))
    ax.set_xticklabels(range(1, 36, 2), fontsize=10)

    # 标题：明确数据与刻度的对齐关系
    #ax.set_title(  '',fontsize=14, fontweight='bold', pad=20 )

    # 颜色条（体现原始功率离散度，数据反转不影响功率范围）
    cbar = fig.colorbar(im, ax=ax, shrink=0.9)
    cbar.set_label(
        f'Transmit Power（dBW)',
        fontsize=16, fontweight='bold'
    )
    cbar_ticks = np.linspace(0, 1, 6)
    cbar.set_ticks(cbar_ticks)
    cbar.set_ticklabels([f'{min_power + (max_power - min_power) * t:.2f}' for t in cbar_ticks])

    # 网格线（增强可读性）
    ax.grid(True, alpha=0.1, color='black', linestyle='-')

    # 保存图片
    plt.tight_layout()
    plt.savefig('干扰机发信功率热力图.png', dpi=300, bbox_inches='tight')
    plt.show()


# --------------------------
# 5. 主函数（不变）
# --------------------------
if __name__ == "__main__":
    # 替换为你的文档实际路径
    file_path = r'D:\desktop\旧的ICCA公开程序\ICCA-main\2025.05.20 公开代码\ICCA  场景3\communication_interference_data.txt'

    # 提取数据
    try:
        power_matrix, cycle_nums = extract_power_data(file_path)
        print(f"✅ 成功提取 {len(cycle_nums)} 次循环，35个干扰机")
    except Exception as e:
        print(f"❌ 数据提取失败：{str(e)}")
        exit(1)

    # 预处理
    power_matrix_filled, power_matrix_norm, (min_power, max_power) = preprocess_data(power_matrix)
    print(f"📊 原始功率范围：{min_power:.2f} ~ {max_power:.2f}（离散度）")

    # 绘制热力图
    try:
        plot_power_heatmap(power_matrix_filled, power_matrix_norm, cycle_nums, min_power, max_power)
        print("✅ 热力图已保存（文件名：干扰机发信功率热力图.png）")
    except Exception as e:
        print(f"❌ 绘图失败：{str(e)}")
        exit(1)