import re
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import chardet


# --------------------------
# 1. 自动检测文件编码
# --------------------------
def detect_file_encoding(file_path):
    with open(file_path, 'rb') as f:
        raw_data = f.read(10000)
        result = chardet.detect(raw_data)
        encoding = result['encoding'] if result['encoding'] else 'gbk'
        confidence = result['confidence']
        print(f"自动检测到文件编码：{encoding}（置信度：{confidence:.2f}）")
        return encoding


# --------------------------
# 2. 数据提取（计算干信比并统计平均值）
# --------------------------
def extract_js_ratio_data(file_path):
    """
    提取communication_data.txt中30个通信节点的干信比
    干信比 = 干扰信号之和（第9列） - 最大接收功率（第8列）
    并计算每个迭代周期的平均值
    """
    encoding = detect_file_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            content = f.read()
        print(f"成功以 {encoding} 编码读取文件")
    except Exception as e:
        print(f"{encoding} 编码失败，重试 GBK：{str(e)}")
        with open(file_path, 'r', encoding='gbk', errors='ignore') as f:
            content = f.read()

    # 匹配所有test_result数据块
    test_result_pattern = r'test_result数据:\s*\[\[(.*?)\]\]'
    result_blocks = re.findall(test_result_pattern, content, re.DOTALL | re.IGNORECASE)

    if not result_blocks:
        raise ValueError("未检测到test_result数据块，请检查communication_data.txt格式")

    # 循环次数
    cycle_nums = list(range(1, len(result_blocks) + 1))
    fixed_node_count = 30  # 固定30个通信节点
    js_ratio_matrix = []  # 干信比矩阵
    js_mean_per_cycle = []  # 每个迭代周期的干信比平均值

    for block in result_blocks:
        # 提取当前循环的所有节点数据行
        node_lines = re.findall(r'\[([\d,\s\.-]+)\]', block)
        # 初始化当前循环的干信比数组
        cycle_js_ratio = [np.nan] * fixed_node_count

        for line in node_lines:
            try:
                # 分割数据并转换为数值
                values = list(map(float, re.split(r',\s*', line.strip())))
                # 验证数据完整性
                if len(values) >= 9:
                    node_id = int(values[0])  # 第1列为通信节点序号（1-30）
                    max_rx_power = values[7]  # 第8列为最大接收功率
                    interference_sum = values[8]  # 第9列为干扰信号之和
                    js_ratio = interference_sum - max_rx_power  # 计算干信比

                    # 过滤无效值
                    if 1 <= node_id <= fixed_node_count:
                        cycle_js_ratio[node_id - 1] = js_ratio if js_ratio != -1000.0 else np.nan
            except ValueError:
                continue

        # 计算当前迭代周期的平均值（排除NaN）
        cycle_mean = np.nanmean(cycle_js_ratio)
        js_mean_per_cycle.append(cycle_mean)
        # 将当前循环的30个节点干信比加入矩阵
        js_ratio_matrix.append(cycle_js_ratio)

    # 转换为numpy数组
    js_ratio_matrix = np.array(js_ratio_matrix)
    print(f"数据提取完成：{len(js_ratio_matrix)} 次循环 × {js_ratio_matrix.shape[1]} 个通信节点")
    return js_ratio_matrix, cycle_nums, js_mean_per_cycle


# --------------------------
# 3. 绘制干信比平均值折线图
# --------------------------
def plot_js_mean_linechart(cycle_nums, js_mean_per_cycle):
    # 解决中文/负号显示问题
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    # 设置画布大小
    fig, ax = plt.subplots(figsize=(14, 8))

    # 绘制折线图
    ax.plot(cycle_nums, js_mean_per_cycle,
            color='#C73E1D', linewidth=2, marker='o',
            markersize=4, linestyle='-', label='Average JSR')

    # 设置坐标轴标签
    ax.set_xlabel('Numbers', fontsize=22, fontweight='bold')
    ax.set_ylabel(' Average JSR(dB)', fontsize=22, fontweight='bold')
    #ax.set_title('30个通信节点干信比平均值随迭代次数变化趋势', fontsize=16, fontweight='bold')

    # 设置刻度
    ax.tick_params(axis='both', which='major', labelsize=18)

    # 添加网格
    ax.grid(True, linestyle='--', alpha=0.7)

    # 添加图例
    ax.legend(fontsize=18)

    # 添加参考线（平均值线）
    overall_mean = np.nanmean(js_mean_per_cycle)
    ax.axhline(y=overall_mean, color='#2E86AB', linestyle='--',
               label=f'Overall JSR Average: {overall_mean:.2f} dB')
    ax.legend(fontsize=18)

    # 调整布局并保存
    plt.tight_layout()
    plt.savefig('通信节点干信比平均值折线图.png', dpi=300, bbox_inches='tight')
    plt.show()


# --------------------------
# 4. 主函数
# --------------------------
if __name__ == "__main__":
    # 替换为实际文件路径
    file_path = r'C:\\Users\\1\\PycharmProjects\\论文4\\12.21 ICCA代码 - 副本\\ICCA  场景2\\communication_data.txt'

    # 步骤1：提取干信比数据及平均值
    try:
        js_matrix, cycle_nums, js_mean_per_cycle = extract_js_ratio_data(file_path)
        print(f"✅ 数据提取成功：{len(cycle_nums)} 次循环，固定30个通信节点")
    except Exception as e:
        print(f"❌ 数据提取失败：{str(e)}")
        exit(1)

    # 步骤2：绘制折线图
    try:
        plot_js_mean_linechart(cycle_nums, js_mean_per_cycle)
        print("✅ 折线图已保存：通信节点干信比平均值折线图.png")
    except Exception as e:
        print(f"❌ 折线图绘制失败：{str(e)}")
        exit(1)