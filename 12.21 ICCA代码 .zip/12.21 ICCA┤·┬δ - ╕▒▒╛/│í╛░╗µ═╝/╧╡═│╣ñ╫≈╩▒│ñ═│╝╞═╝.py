import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle

# 1. 数据准备（与之前一致）
scenarios = ['Scenario 1', 'Scenario 2', 'Scenario 3']
icca_values = [11.6, 11.1, 10.9]
fpja_values = [10.43, 10.43, 10.43]
madjpa_values = [0, 0, 0]
srsa_values = [0, 0, 0]
ga_values = [0, 0, 0]

# 误差值
icca_error = [0.7, 0.4, 0.4]
fpja_error = [0, 0, 0]
madjpa_error = [0, 0, 0]
srsa_error = [0, 0, 0]
ga_error = [0, 0, 0]

# 2. Nature风格全局配置（放大所有文字）
plt.rcParams['font.family'] = 'Arial'  # Nature指定字体
plt.rcParams['font.size'] = 14        # 全局文字放大
plt.rcParams['axes.linewidth'] = 1.0  # 线条加粗适配大文字
plt.rcParams['xtick.major.width'] = 1.0
plt.rcParams['ytick.major.width'] = 1.0
plt.rcParams['legend.fontsize'] = 13  # 图例文字
plt.rcParams['axes.labelsize'] = 15   # 坐标轴标签文字

# 3. 定义基础颜色（图例纯色、柱子渐变基于此）
icca_color = '#1f77b4'    # ICCA纯色（蓝）
fpja_color = '#ff7f0e'    # FPJA纯色（橙）

# 4. 绘图（调整画布尺寸适配大文字）
x = np.arange(len(scenarios))
width = 0.15  # 柱子宽度
fig, ax = plt.subplots(figsize=(9, 5.5))  # 加宽加高画布

# ---------------------- 绘制ICCA渐变柱状图 ----------------------
icca_bars = ax.bar(x - 2*width, icca_values, width,
                   yerr=icca_error, capsize=4,
                   edgecolor=icca_color, linewidth=1.0,
                   facecolor='none')  # 先设为无填充
# 为每个ICCA柱子添加垂直渐变（从下到上透明度递增）
for i, bar in enumerate(icca_bars):
    height = bar.get_height()
    alpha = np.linspace(0.4, 1.0, int(height*10))  # 渐变步长
    for j in range(len(alpha)-1):
        rect = Rectangle((bar.get_x(), j*0.1), width, 0.1,
                         facecolor=icca_color,
                         alpha=alpha[j],
                         edgecolor='none')
        ax.add_patch(rect)

# ---------------------- 绘制FPJA渐变柱状图 ----------------------
fpja_bars = ax.bar(x - width, fpja_values, width,
                   yerr=fpja_error, capsize=4,
                   edgecolor=fpja_color, linewidth=1.0,
                   facecolor='none')
# 为每个FPJA柱子添加垂直渐变
for i, bar in enumerate(fpja_bars):
    height = bar.get_height()
    alpha = np.linspace(0.4, 1.0, int(height*10))
    for j in range(len(alpha)-1):
        rect = Rectangle((bar.get_x(), j*0.1), width, 0.1,
                         facecolor=fpja_color,
                         alpha=alpha[j],
                         edgecolor='none')
        ax.add_patch(rect)

# ---------------------- 绘制后3个算法占位柱 ----------------------
ax.bar(x, madjpa_values, width,
       color='none', edgecolor='none', yerr=madjpa_error)
ax.bar(x + width, srsa_values, width,
       color='none', edgecolor='none', yerr=srsa_error)
ax.bar(x + 2*width, ga_values, width,
       color='none', edgecolor='none', yerr=ga_error)

# ---------------------- 兼容版长方形图例（核心修复，全版本可用） ----------------------
# 方法：用"竖线+纯色填充"模拟长方形，全Matplotlib版本兼容
def make_custom_legend_patch(color, width=0.8, height=2):
    """创建自定义长方形图例块（宽width，高height）"""
    return plt.Rectangle((0, 0), width, height,
                         facecolor=color, edgecolor='none')

# 创建图例块：宽0.8（不变）、高2（拉长）
legend_handles = [
    make_custom_legend_patch(icca_color),
    make_custom_legend_patch(fpja_color)
]
# 添加图例，手动指定标签和尺寸
ax.legend(handles=legend_handles,
          labels=['ICCA', 'FPJA'],
          frameon=False, loc='upper right',
          handlelength=2,  # 控制长方形长度（越大越长）
          handleheight=1,  # 控制长方形宽度（保持不变）
          handletextpad=0.5)  # 图例块与文字间距

# 5. 图表样式最终调整
ax.set_ylabel('Operation duration of system(h)')  # 纵轴标题
ax.set_xticks(x)
ax.set_xticklabels(scenarios, rotation=0, fontsize=14)  # 横轴文字
ax.tick_params(axis='y', labelsize=14)  # 纵轴刻度文字
# Nature风格：隐藏顶部/右侧边框
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

# 6. 保存/显示
plt.tight_layout()
plt.savefig('nature_style_barplot_final.pdf', dpi=300, bbox_inches='tight')
plt.show()