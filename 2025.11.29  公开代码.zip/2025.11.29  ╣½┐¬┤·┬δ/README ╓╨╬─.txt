本论文设计的ICCA算法
运行python集成开发环境（IDE）版本：
PyCharm 2023.2.1 (Professional Edition)
Runtime version: 17.0.8+7-b1000.8 amd64
搭载的第三方库：anaconda_depends_2023.09  以及  PyTorch版本: 1.13.1  

增设了Figure 4. Scenario 1. 、Figure 5. Scenario 2.和Figure 6. Scenario 3.的绘制程序，直接运行即可生成图像。

在每个场景文件中：
1.打开main，点击运行可以直接按照默认设置，运行一次本算法，修改程序最后的运行次数，可以重复运行/
2.generate_nodes.py为算法1仿真程序。
3.modify_communication_nodes.py为算法2的仿真程序。
4.jammer_first_run.py为干扰方依据策略第一次决策的干扰程序。
5.jammer_run.py为干扰方依据策略非第一次决策的干扰程序。
6.test.py为仿真场景中干扰效果的检测程序。
7.设置了随机数种子。
8.输出communication_data.txt，记录每次干扰机决策后，仿真场景中通信节点处的状态信息。依次为（通信节点序号、通信节点类型、x坐标、y坐标、z坐标、该节点处的电磁环境噪声、该通信节点的发信功率、该通信节点处通信信号最大接收功率、该通信节点处通信干扰信号之和）。
9.输出communication_interference_data.txt，记录每次干扰机决策后，仿真场景中干扰机处的状态信息。依次为（干扰机序号、干扰机类型、x坐标、y坐标、z坐标、该节点处的电磁环境噪声、该干扰机的干扰功率、该干扰机的剩余电量）。
10.点击运行“数据统计”程序，可以计算出论文中的对比数据
11.点击 运行“干扰机发信功率统计.py，干信比 平均折线图.py，通信节点发信功率热力图.py，通信节点干信比热力图.py”文件，可以基于一次实验结果，生成对映的图片。