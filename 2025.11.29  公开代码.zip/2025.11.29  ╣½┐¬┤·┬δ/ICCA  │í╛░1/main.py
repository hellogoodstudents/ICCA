from generate_nodes import generate_nodes
from modify_communication_nodes import modify_communication_nodes
import pickle
import numpy as np
import time
import test
import jammer_run
import jammer_first_run
# 导入 test.py 模块
#1.运行main，将生成的通信节点信息和干扰机信息（无剩余功率）保存到文件中（layout_result 和 nodes_first），表示未更新的干扰机信息。
# 2.运行jammer_first_run，第一次计算干扰机的剩余功率，将更新后的 干扰机信息 保存到文件updated_layout_result中
#3.回到main，将updated_layout_result覆盖在layout_result中。
# 4.运行main，启动test，以新的干扰机信息和通信节点信息（layout_result和communication），进行测试，判断干扰是否符合干信比为3的要求。

np.random.seed(36) #固定随机数种子，确保每次运行结果一致



def save_layout_result(layout_result, nodes_first):
    """
    将 layout_result 和 nodes_first 保存到文件中。
    """
    # 保存 layout_result
    with open("layout_result.pkl", "wb") as f:  #含干扰机剩余能量
        pickle.dump(layout_result, f)

    # 保存 nodes_first
    with open("nodes_first.pkl", "wb") as f:
        pickle.dump(nodes_first, f)

    print("layout_result 和 nodes_first 已保存到文件中。")



def load_layout_result():
    """
    从文件中加载更新后的 updated_layout_result。
    """
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
    return layout_result

def load_nodes_first():
    """
    从文件中加载更新后的 nodes_first。
    """
    with open("nodes_first.pkl", "rb") as f:
        nodes_first = pickle.load(f)
    return nodes_first


def main():

    nodes_first = [
    [1, 1, 41300, 6600, 2500, -107, -89.05],
    [2, 1, 7800, 5000, 2100, -112, -90.77],
    [3, 1, 19600, 38700, 2900, -112, -93.91],
    [4, 1, 3700, 19300, 2100, -113, -89.08],
    [5, 1, 19800, 25700, 2700, -107, -94.04],
    [6, 1, 30000, 7800, 2200, -115, -88.18],
    [7, 1, 30200, 44200, 2400, -108, -94.04],
    [8, 1, 7000, 26000, 2800, -108, -90.0],
    [9, 1, 3900, 9700, 2700, -112, -87.85],
    [10, 1, 30000, 29800, 2600, -111, -94.41],
    [11, 2, 13700, 33400, 10, -96, -83.5],
    [12, 2, 26800, 48600, 10, -98, -89.12],
    [13, 2, 18900, 33500, 10, -101, -83.5],
    [14, 2, 3700, 4000, 10, -105, -89.63],
    [15, 2, 46300, 5300, 10, -97, -88.31],
    [16, 2, 11900, 27200, 10, -96, -86.32],
    [17, 2, 24500, 28400, 10, -104, -88.4],
    [18, 2, 31300, 10700, 10, -104, -85.46],
    [19, 2, 20700, 3200, 10, -98, -82.05],
    [20, 2, 22900, 7300, 10, -104, -82.05],
    [21, 2, 40200, 9700, 10, -98, -86.0],
    [22, 2, 33900, 39700, 10, -97, -87.29],
    [23, 2, 34800, 32800, 10, -95, -87.29],
    [24, 2, 4300, 12300, 10, -103, -79.18],
    [25, 2, 19700, 44900, 10, -104, -89.12],
    [26, 2, 15700, 21400, 10, -105, -87.25],
    [27, 2, 35100, 6000, 10, -101, -85.46],
    [28, 2, 3000, 15800, 10, -96, -79.18],
    [29, 2, 14000, 4800, 10, -103, -87.16],
    [30, 2, 3800, 24700, 10, -98, -89.87],
]

    #序号、类别、x、y、z、环境噪声、最大通信接收功率
    # 将第7列内容全部换算成1，表示频段为1
    for node in nodes_first:
        node[6] = 1  # 第7列表示频段，设置为1

    # 调用 generate_nodes 函数，生成初始的通信节点信息
    nodes_first = generate_nodes(nodes_first)

    print('nodes_first',nodes_first)


    # 定义 layout_result，干扰机位置
    layout_result = [
        [1, 0, 27583, 48974, 3, -97],
        [2, 0, 3912, 23459, 3, -99],
        [3, 0, 34319, 32026, 3, -95],
        [4, 0, 20289, 1876, 3, -103],
        [5, 0, 39676, 10332, 3, -103],
        [6, 0, 4049, 11539, 3, -100],
        [7, 0, 18263, 33663, 3, -98],
        [8, 0, 13441, 5543, 3, -100],
        [9, 0, 5134, 25115, 3, -96],
        [10, 1, 40308, 5744, 1964, -112],
        [11, 0, 3197, 3130, 3, -96],
        [12, 1, 21774, 43245, 800, -106],
        [13, 1, 34023, 38614, 1044, -105],
        [14, 0, 2370, 14958, 3, -97],
        [15, 0, 12384, 27813, 3, -97],
        [16, 0, 34276, 5291, 3, -95],
        [17, 0, 16777, 21361, 3, -102],
        [18, 0, 22178, 8006, 3, -98],
        [19, 0, 28485, 7117, 3, -101],
        [20, 0, 47058, 4547, 3, -104],
        [21, 0, 23300, 27295, 3, -101],
        [22, 1, 7000, 8000, 1200, -105],
        [23, 0, 5000, 6000, 3, -95],
        [24, 0, 18077, 4000, 3, -102],
        [25, 1, 4000, 16006, 1200, -106],
        [26, 0, 25295, 8304, 3, -95],
        [27, 0, 32211, 8082, 3, -98],
        [28, 1, 33485, 10117, 1100, -108],
        [29, 1, 14108, 32914, 800, -105],
        [30, 1, 24170, 44677, 1300, -106],
        [31, 0, 18900, 26095, 3, -99],
        [32, 0, 18000, 37095, 3, -99],
    ]
    #序号、类别、x、y、z、电磁环境噪声dBW

    # 保存 layout_result 和 nodes_first 到文件
    save_layout_result(layout_result, nodes_first)

    # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

    layout_result, elapsed_time = jammer_first_run.main_jammer_run()


    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中

    # 将第1次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中
    with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
        f.write(f"1次循环通信干扰决策\n")
        f.write(f"程序运行时长: {elapsed_time} 秒\n")
        f.write("layout_result数据:\n")
        for item in layout_result:
            f.write(f"{item}\n")

    # 加载第一次干扰更新后的 layout_result，干扰机序号、类型、x、y、z、功率w、剩余能量AH
    updated_layout_result = load_layout_result()
    #print("第一次更新后的 干扰机layout_result：", updated_layout_result,)



    #  将更新后的 updated_layout_result 保存到文件中 保存到 jammer.pkl 供 test.py 使用  ,不含干扰机剩余能量



    # 删除第 7、8 列数据（索引为 6、7）,对初始的通信节点nodes_first，处理，

    columns_to_delete = [6, 7]
    communication2 = np.delete(nodes_first, columns_to_delete, axis=1)
    # 将 communication2 转换为列表
    communication2 = communication2.tolist()

    print('communication2:')
    for row in communication2:
        print(row)

    # 将 communication2 保存到 communication.pkl 供 test.py 使用
    with open("communication.pkl", "wb") as f:
        pickle.dump(communication2, f)


    # 调用 test.py 的测试函数
    test_result = test.run_test(communication2, updated_layout_result)

    # 根据测试结果输出信息
    if test_result["success"]:
        print("第一次通信干扰成功！")

        # 依据成功干扰后的communication，生成新的通信信息，读取含剩余能量的layout_result,得到新的干扰机信息layout_result
        i = 2  # 初始化循环次数
        while True:
            communication = modify_communication_nodes()
            #print('功率调整后的通信方', communication)  # 序号、类型、x坐标、y坐标、z坐标、

            # 使用 os.system 调用 jammer_run.py，进行一次通信干扰资源调度

            layout_result, elapsed_time = jammer_run.main_jammer_run()

            # 调用 test.py 的测试函数
            test_result = test.run_test(communication, layout_result)

            # 根据测试结果输出信息
            if test_result["success"]:
                print(f"第{i}次通信干扰成功！")
                # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,有用的次数减1
                with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                    f.write(f"{i}次循环通信干扰决策\n")
                    f.write(f"程序运行时长: {elapsed_time} 秒\n")
                    f.write("layout_result数据:\n")
                    for item in layout_result:
                        f.write(f"{item}\n")

                i += 1  # 循环次数加1

            else:
                print(f"第{i}次通信干扰失败！")
                print("以下通信节点达不到不符合干信比为3的干扰：")
                for warning in test_result["warnings"]:
                    print(warning)

                # 将第i次循环通信干扰决策、程序运行时长、layout_result数据保存到新建的txt文档中,保留最后失败的干扰数据，有用的次数减1
                with open(f"communication_interference_data.txt", "a") as f:  # 将 "w" 改为 "a",不覆盖原有的信息
                    f.write(f"{i}次循环通信干扰决策\n")
                    f.write(f"程序运行时长: {elapsed_time} 秒\n")
                    f.write("layout_result数据:\n")
                    for item in layout_result:
                        f.write(f"{item}\n")

                break  # 通信干扰失败，停止循环

        layout_result = load_layout_result()
        print("干扰失败后，最后更新后的 干扰机layout_result：", layout_result)
        print("干扰失败后，最后更新后的 communication：", communication)



    else:
        print("以下通信节点不符合干信比为3的干扰：")
        for warning in test_result["warnings"]:
            print(warning)





if __name__ == '__main__':
    for _ in range(1):  #程序运行30次
        main()