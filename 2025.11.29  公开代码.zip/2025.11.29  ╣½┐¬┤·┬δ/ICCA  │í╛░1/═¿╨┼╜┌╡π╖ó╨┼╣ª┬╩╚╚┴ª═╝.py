import re
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
import chardet


# --------------------------
# 1. 自动检测文件编码（不变）
# --------------------------
def detect_file_encoding(file_path):
    with open(file_path, 'rb') as f:
        raw_data = f.read(10000)
        result = chardet.detect(raw_data)
        encoding = result['encoding'] if result['encoding'] else 'gbk'
        confidence = result['confidence']
        print(f"自动检测到文件编码：{encoding}（置信度：{confidence:.2f}）")
        return encoding


# --------------------------
# 2. 数据提取（固定30个通信节点，适配第7列发信功率）
# --------------------------
def extract_communication_power_data(file_path):
    """
    提取communication_data.txt中30个通信节点的发信功率（第7列）
    格式：通信节点序号(1-30)、类型、x、y、z、噪声、发信功率、最大接收功率、干扰信号和
    固定节点数：30个，确保数据矩阵维度统一
    """
    encoding = detect_file_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            content = f.read()
        print(f"成功以 {encoding} 编码读取文件")
    except Exception as e:
        print(f"{encoding} 编码失败，重试 GBK：{str(e)}")
        with open(file_path, 'r', encoding='gbk', errors='ignore') as f:
            content = f.read()

    # 匹配所有test_result数据块（每个块对应一次循环决策）
    test_result_pattern = r'test_result数据:\s*\[\[(.*?)\]\]'
    result_blocks = re.findall(test_result_pattern, content, re.DOTALL | re.IGNORECASE)

    if not result_blocks:
        raise ValueError("未检测到test_result数据块，请检查communication_data.txt格式")

    # 循环次数：从1开始递增（与数据块数量一致）
    cycle_nums = list(range(1, len(result_blocks) + 1))
    fixed_node_count = 30  # 固定30个通信节点
    power_matrix = []

    for block in result_blocks:
        # 提取当前循环的所有节点数据行（格式：[1,1,41300,...], [2,1,7800,...]...）
        node_lines = re.findall(r'\[([\d,\s\.-]+)\]', block)
        # 初始化当前循环的功率数组（30个节点，默认NaN）
        cycle_power = [np.nan] * fixed_node_count

        for line in node_lines:
            try:
                # 分割数据并转换为数值（处理逗号+空格的分隔格式）
                values = list(map(float, re.split(r',\s*', line.strip())))
                # 验证数据完整性（至少8列，确保能取到第7列发信功率）
                if len(values) >= 8:
                    node_id = int(values[0])  # 第1列为通信节点序号（1-30）
                    tx_power = values[6]  # 第7列为发信功率
                    # 过滤无效值（文件中-1000.0为无效数据，仍保留NaN）
                    if 1 <= node_id <= fixed_node_count:  # 仅处理1-30号节点
                        cycle_power[node_id - 1] = tx_power if tx_power != -1000.0 else np.nan
            except ValueError:
                # 跳过无法转换为数值的异常行（如格式错乱数据）
                continue

        # 将当前循环的30个节点功率加入矩阵
        power_matrix.append(cycle_power)

    # 转换为numpy数组（维度：循环次数 × 30个节点）
    power_matrix = np.array(power_matrix)
    print(f"数据提取完成：{len(power_matrix)} 次循环 × {power_matrix.shape[1]} 个通信节点")
    return power_matrix, cycle_nums


# --------------------------
# 3. 数据预处理（填充缺失值+标准化）
# --------------------------
def preprocess_data(power_matrix):
    # 填充缺失值：用当前循环的功率均值填充（避免NaN影响热力图）
    power_matrix_filled = np.copy(power_matrix)
    for i in range(power_matrix_filled.shape[0]):
        # 计算当前循环的有效功率均值（排除NaN）
        cycle_mean = np.nanmean(power_matrix_filled[i])
        # 替换NaN为均值
        power_matrix_filled[i] = np.where(np.isnan(power_matrix_filled[i]), cycle_mean, power_matrix_filled[i])

    # 标准化（0-1范围）：增强热力图颜色对比度，便于观察功率差异
    min_power = np.min(power_matrix_filled)
    max_power = np.max(power_matrix_filled)
    power_matrix_norm = (power_matrix_filled - min_power) / (max_power - min_power)

    return power_matrix_filled, power_matrix_norm, (min_power, max_power)


# --------------------------
# 4. 热力图可视化（固定30个节点，保持原有风格）
# --------------------------
def plot_communication_power_heatmap(power_matrix_filled, power_matrix_norm, cycle_nums, min_power, max_power):
    # 解决中文/负号显示问题
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    # 设置画布大小（适配30个节点的横轴长度）
    fig, ax = plt.subplots(figsize=(14, 10))

    # 颜色映射：低功率（蓝）→ 高功率（红），与原有干扰机热力图风格统一
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D']
    cmap = LinearSegmentedColormap.from_list('power_cmap', colors, N=256)

    # 核心：反转数据矩阵行顺序 → 第1次循环在热力图底部，最后1次在顶部
    power_matrix_norm_reversed = power_matrix_norm[::-1]
    max_cycle = len(cycle_nums)  # 实际循环次数
    fixed_node_count = 30  # 固定30个通信节点

    # 绘制热力图：X轴=30个节点，Y轴=循环次数
    im = ax.imshow(
        power_matrix_norm_reversed,
        cmap=cmap,
        aspect='auto',  # 自动调整纵横比，避免节点挤压
        # X轴范围：0.5~30.5（确保每个节点对应一个完整列）；Y轴范围：0~总循环数（底部=第1次，顶部=最后1次）
        extent=[0.5, fixed_node_count + 0.5, 0, max_cycle]
    )

    # --------------------------
    # 纵轴设置（循环次数：0,100,200...粗略刻度）
    # --------------------------
    ax.set_ylabel('Numbers', fontsize=16, fontweight='bold')
    # 生成粗略刻度（步长100，不超过总循环数）
    rough_ticks = list(range(0, max_cycle + 100, 100))
    rough_ticks = [tick for tick in rough_ticks if tick <= max_cycle]
    # 刻度位置=刻度值（直接对应Y轴范围，无需反向映射）
    ax.set_yticks(rough_ticks)
    ax.set_yticklabels([str(tick) for tick in rough_ticks], fontsize=10)

    # --------------------------
    # 横轴设置（固定30个通信节点，每3个显示一个刻度，避免拥挤）
    # --------------------------
    ax.set_xlabel('Communication node numbers', fontsize=16, fontweight='bold')
    # 刻度步长=3（1,4,7...28），确保30个节点的刻度清晰不重叠
    ax.set_xticks(range(1, fixed_node_count + 1, 3))
    ax.set_xticklabels(range(1, fixed_node_count + 1, 3), fontsize=10)

    # --------------------------
    # 颜色条（标注发信功率单位，体现离散度）
    # --------------------------
    cbar = fig.colorbar(im, ax=ax, shrink=0.9)
    cbar.set_label(
        f'Transmit Power (dBW)',
        fontsize=16, fontweight='bold'
    )
    # 颜色条刻度：对应原始功率值（0-1标准化映射回实际范围）
    cbar_ticks = np.linspace(0, 1, 6)
    cbar.set_ticks(cbar_ticks)
    cbar.set_ticklabels([f'{min_power + (max_power - min_power) * t:.2f}' for t in cbar_ticks], fontsize=10)

    # 网格线：增强节点与循环的区分度（透明度0.1避免遮挡）
    ax.grid(True, alpha=0.1, color='black', linestyle='-')

    # 保存图片（高分辨率300dpi，避免刻度/颜色条截断）
    plt.tight_layout()
    plt.savefig('通信节点发信功率热力图_30节点.png', dpi=300, bbox_inches='tight')
    plt.show()


# --------------------------
# 5. 主函数（整合全流程）
# --------------------------
if __name__ == "__main__":
    # ！！！关键：替换为你的communication_data.txt实际路径
    file_path = r'D:\desktop\旧的ICCA公开程序\ICCA-main\2025.05.20 公开代码\ICCA  场景1\communication_data.txt'

    # 步骤1：提取30个通信节点的发信功率数据
    try:
        power_matrix, cycle_nums = extract_communication_power_data(file_path)
        print(f"✅ 数据提取成功：{len(cycle_nums)} 次循环，固定30个通信节点")
    except Exception as e:
        print(f"❌ 数据提取失败：{str(e)}")
        exit(1)

    # 步骤2：预处理数据（填充缺失值+标准化）
    power_matrix_filled, power_matrix_norm, (min_power, max_power) = preprocess_data(power_matrix)
    print(f"📊 发信功率统计：范围 {min_power:.2f} ~ {max_power:.2f} dBW（离散度）")

    # 步骤3：绘制热力图
    try:
        plot_communication_power_heatmap(power_matrix_filled, power_matrix_norm, cycle_nums, min_power, max_power)
        print("✅ 热力图已保存：通信节点发信功率热力图_30节点.png")
    except Exception as e:
        print(f"❌ 热力图绘制失败：{str(e)}")
        exit(1)