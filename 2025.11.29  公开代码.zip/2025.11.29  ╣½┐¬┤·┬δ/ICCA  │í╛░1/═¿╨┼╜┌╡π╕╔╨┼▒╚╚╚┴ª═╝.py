import re
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import chardet


# --------------------------
# 1. 自动检测文件编码
# --------------------------
def detect_file_encoding(file_path):
    with open(file_path, 'rb') as f:
        raw_data = f.read(10000)
        result = chardet.detect(raw_data)
        encoding = result['encoding'] if result['encoding'] else 'gbk'
        confidence = result['confidence']
        print(f"自动检测到文件编码：{encoding}（置信度：{confidence:.2f}）")
        return encoding


# --------------------------
# 2. 数据提取（计算干信比：干扰信号之和 - 最大接收功率）
# --------------------------
def extract_jammer_to_signal_ratio_data(file_path):
    """
    提取communication_data.txt中30个通信节点的干信比
    干信比 = 干扰信号之和（第9列） - 最大接收功率（第8列）
    格式：通信节点序号(1-30)、类型、x、y、z、噪声、发信功率、最大接收功率、干扰信号和
    """
    encoding = detect_file_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            content = f.read()
        print(f"成功以 {encoding} 编码读取文件")
    except Exception as e:
        print(f"{encoding} 编码失败，重试 GBK：{str(e)}")
        with open(file_path, 'r', encoding='gbk', errors='ignore') as f:
            content = f.read()

    # 匹配所有test_result数据块
    test_result_pattern = r'test_result数据:\s*\[\[(.*?)\]\]'
    result_blocks = re.findall(test_result_pattern, content, re.DOTALL | re.IGNORECASE)

    if not result_blocks:
        raise ValueError("未检测到test_result数据块，请检查communication_data.txt格式")

    # 循环次数
    cycle_nums = list(range(1, len(result_blocks) + 1))
    fixed_node_count = 30  # 固定30个通信节点
    js_ratio_matrix = []  # 干信比矩阵

    for block in result_blocks:
        # 提取当前循环的所有节点数据行
        node_lines = re.findall(r'\[([\d,\s\.-]+)\]', block)
        # 初始化当前循环的干信比数组
        cycle_js_ratio = [np.nan] * fixed_node_count

        for line in node_lines:
            try:
                # 分割数据并转换为数值
                values = list(map(float, re.split(r',\s*', line.strip())))
                # 验证数据完整性（至少9列，确保能计算干信比）
                if len(values) >= 9:
                    node_id = int(values[0])  # 第1列为通信节点序号（1-30）
                    max_rx_power = values[7]  # 第8列为最大接收功率
                    interference_sum = values[8]  # 第9列为干扰信号之和
                    js_ratio = interference_sum - max_rx_power  # 计算干信比

                    # 过滤无效值
                    if 1 <= node_id <= fixed_node_count:
                        cycle_js_ratio[node_id - 1] = js_ratio if js_ratio != -1000.0 else np.nan
            except ValueError:
                continue

        # 将当前循环的30个节点干信比加入矩阵
        js_ratio_matrix.append(cycle_js_ratio)

    # 转换为numpy数组（维度：循环次数 × 30个节点）
    js_ratio_matrix = np.array(js_ratio_matrix)
    print(f"数据提取完成：{len(js_ratio_matrix)} 次循环 × {js_ratio_matrix.shape[1]} 个通信节点")
    return js_ratio_matrix, cycle_nums


# --------------------------
# 3. 数据预处理（填充缺失值+标准化）
# --------------------------
def preprocess_data(data_matrix):
    # 填充缺失值：用当前循环的均值填充
    data_matrix_filled = np.copy(data_matrix)
    for i in range(data_matrix_filled.shape[0]):
        cycle_mean = np.nanmean(data_matrix_filled[i])
        data_matrix_filled[i] = np.where(np.isnan(data_matrix_filled[i]), cycle_mean, data_matrix_filled[i])

    # 标准化（0-1范围）
    min_val = np.min(data_matrix_filled)
    max_val = np.max(data_matrix_filled)
    data_matrix_norm = (data_matrix_filled - min_val) / (max_val - min_val) if (
                                                                                           max_val - min_val) != 0 else data_matrix_filled

    return data_matrix_filled, data_matrix_norm, (min_val, max_val)


# --------------------------
# 4. 干信比热力图可视化
# --------------------------
def plot_js_ratio_heatmap(data_matrix_filled, data_matrix_norm, cycle_nums, min_val, max_val):
    # 解决中文/负号显示问题
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    # 设置画布大小
    fig, ax = plt.subplots(figsize=(14, 10))

    # 颜色映射：保持与原风格一致（低→高：蓝→红）
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D']
    cmap = LinearSegmentedColormap.from_list('js_cmap', colors, N=256)

    # 反转数据矩阵行顺序
    data_matrix_norm_reversed = data_matrix_norm[::-1]
    max_cycle = len(cycle_nums)
    fixed_node_count = 30

    # 绘制热力图
    im = ax.imshow(
        data_matrix_norm_reversed,
        cmap=cmap,
        aspect='auto',
        extent=[0.5, fixed_node_count + 0.5, 0, max_cycle]
    )

    # 纵轴设置（循环次数）
    ax.set_ylabel('Numbers', fontsize=16, fontweight='bold')
    rough_ticks = list(range(0, max_cycle + 100, 100))
    rough_ticks = [tick for tick in rough_ticks if tick <= max_cycle]
    ax.set_yticks(rough_ticks)
    ax.set_yticklabels([str(tick) for tick in rough_ticks], fontsize=10)

    # 横轴设置（通信节点）
    ax.set_xlabel('Communication node numbers', fontsize=16, fontweight='bold')
    ax.set_xticks(range(1, fixed_node_count + 1, 3))
    ax.set_xticklabels(range(1, fixed_node_count + 1, 3), fontsize=10)

    # 颜色条（标注干信比）
    cbar = fig.colorbar(im, ax=ax, shrink=0.9)
    cbar.set_label(
        f'JSR(dB)',  # 干信比通常用分贝表示
        fontsize=16, fontweight='bold'
    )
    # 颜色条刻度映射回实际值范围
    cbar_ticks = np.linspace(0, 1, 6)
    cbar.set_ticks(cbar_ticks)
    cbar.set_ticklabels([f'{min_val + (max_val - min_val) * t:.2f}' for t in cbar_ticks], fontsize=10)

    # 网格线
    ax.grid(True, alpha=0.1, color='black', linestyle='-')

    # 保存图片
    plt.tight_layout()
    plt.savefig('通信节点干信比热力图_30节点.png', dpi=300, bbox_inches='tight')
    plt.show()


# --------------------------
# 5. 主函数
# --------------------------
if __name__ == "__main__":
    # 替换为实际文件路径
    file_path = r'D:\desktop\旧的ICCA公开程序\ICCA-main\2025.05.20 公开代码\ICCA  场景1\communication_data.txt'

    # 步骤1：提取干信比数据
    try:
        js_matrix, cycle_nums = extract_jammer_to_signal_ratio_data(file_path)
        print(f"✅ 数据提取成功：{len(cycle_nums)} 次循环，固定30个通信节点")
    except Exception as e:
        print(f"❌ 数据提取失败：{str(e)}")
        exit(1)

    # 步骤2：预处理数据
    js_matrix_filled, js_matrix_norm, (min_js, max_js) = preprocess_data(js_matrix)
    print(f"📊 干信比统计：范围 {min_js:.2f} ~ {max_js:.2f} dB（离散度）")

    # 步骤3：绘制热力图
    try:
        plot_js_ratio_heatmap(js_matrix_filled, js_matrix_norm, cycle_nums, min_js, max_js)
        print("✅ 热力图已保存：通信节点干信比热力图_30节点.png")
    except Exception as e:
        print(f"❌ 热力图绘制失败：{str(e)}")
        exit(1)