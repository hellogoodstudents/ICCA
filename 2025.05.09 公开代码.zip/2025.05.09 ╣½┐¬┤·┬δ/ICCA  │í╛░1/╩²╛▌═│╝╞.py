import time

# 以二进制模式打开文件
with open('communication_interference_data.txt', 'rb') as file:
    binary_content = file.read()

try:
    # 尝试使用UTF-8解码
    content = binary_content.decode('utf-8')
except UnicodeDecodeError:
    try:
        # 尝试使用GBK解码
        content = binary_content.decode('GBK')
    except UnicodeDecodeError:
        # 其他编码...
        print("无法确定文件的正确编码")
        content = ""

# 初始化变量
interference_count = 0
total_runtime = 0
total_loop_value = 0
loop_count = 0
valid_list_count = 0  # 初始化符合条件的循环次数记录数量

# 按行处理文件内容
lines = content.split('\n')
for line in lines:
    if '程序运行时长:' in line:
        # 提取运行时长
        runtime = float(line.split(': ')[1].split(' ')[0])
        total_runtime += runtime
        loop_count += 1
    elif '循环通信干扰决策' in line:
        # 提取xxx次循环通信干扰决策中的数值xxx
        try:
            loop_num = int(line.split('次')[0])
            total_loop_value += loop_num
            valid_list_count += 1
            interference_count += 1
        except ValueError:
            print(f"解析循环次数时出错：{line}")

# 计算平均值
average_runtime = total_runtime / loop_count if loop_count > 0 else 0
average_loop_value = total_loop_value / valid_list_count if valid_list_count > 0 else 0
# 输出结果
interference_count = interference_count - 1
t = interference_count * 0.025



print(f"有效干扰的次数: {interference_count}")  #至少干扰1次
print(f"程序运行时长的平均值: {average_runtime:.6f} 秒")
#print(f"xxx次循环通信干扰决策中数值xxx的平均值: {average_loop_value:.2f}")
print('平均有效系统工作时长',t,'H')




def count_chenggong_success():
    # 以二进制模式打开文件
    with open('communication_interference_data.txt', 'rb') as file:
        binary_content = file.read()

    try:
        # 尝试使用UTF-8解码
        content = binary_content.decode('utf-8')
    except UnicodeDecodeError:
        try:
            # 尝试使用GBK解码
            content = binary_content.decode('GBK')
        except UnicodeDecodeError:
            # 其他编码...
            print("无法确定文件的正确编码")
            content = ""

    # 初始化计数器
    chenggong_success_count = 0

    # 按行处理文件内容
    lines = content.split('\n')
    for line in lines:
        if line.strip() == 'chenggong: 1':
            chenggong_success_count += 1

    return chenggong_success_count

if __name__ == "__main__":
    success_count = count_chenggong_success()

    xx = round(success_count/interference_count,2)
    print(f"'chenggong: 1' 出现的次数: {success_count}")
    print(f"'整体干扰的百分比: {xx}")