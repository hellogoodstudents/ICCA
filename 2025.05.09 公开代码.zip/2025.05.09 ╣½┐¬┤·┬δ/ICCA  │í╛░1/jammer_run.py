import pickle
import numpy as np
import math
import time
import copy
import random

# 干信比三倍，相当于4.77dB
Interference_distance = [14, 20, 26, 30] #地面干扰机对地面干扰机，地面通信设备对地面干扰机，地面通信设备对地面通信设备，视距通信传播距离极限


com_max_receive = [-89.05, -90.77, -93.91, -89.08, -94.04, -88.18, -94.04, -90.0, -87.85, -94.41,
                   -83.5, -89.12, -83.5, -89.63, -88.31, -86.32, -88.4, -85.46, -82.05, -82.05,
                   -86.0, -87.29, -87.29, -79.18, -89.12, -87.25, -85.46, -79.18, -87.16, -89.87,]

Interference_decision = [
    [2.8, 5.2, 7.8, 10.4, 15, 20],
    [1.7, 3, 4.5, 6, 10, 16],
    [3.1, 6.2, 9.3, 12.4, 15, 20],
]  # 空中干扰机针对地面通信目标和空中通信目标，地面干扰机针对地面通信目标，地面干扰机针对空中通信目标，





def load_layout_result():
    """
    从文件中加载 layout_result 和 communication。
    """
    # 加载 layout_result
    with open("layout_result.pkl", "rb") as f:
        layout_result = pickle.load(f)
        for row in layout_result:
                row[6] = 0  #干扰机发信功率全部设置为0

    # 加载 communication
    with open("communication.pkl", "rb") as f:
        communication = pickle.load(f)

    return layout_result, communication


def save_layout_result(layout_result):
    """
    将更新后的 updated_layout_result 保存到文件中。
    """
    with open("layout_result.pkl", "wb") as f:
        pickle.dump(layout_result, f)
    print("更新后的 layout_result 已保存到文件中。")


def load_interference_info():
    """
    从文件中加载interference_info。
    """
    # 加载 interference_info
    with open("interference_info.pkl", "rb") as f:
        interference_info = pickle.load(f)

    return interference_info


# 传播损耗计算公式
L_sight = lambda d: 30 * np.log10(d) + 20 * np.log10(600) + 32.5
L_two_ray = lambda d, h_t, h_r: (
        30 * np.log10(d) - 20 * np.log10(max(h_t, 1e-10)) - 20 * np.log10(max(h_r, 1e-10)) + 120
)

# 通信节点接收干扰功率的计算，Gtr为链路功率增益，Lpc取固定值1。视距传播中Lc_j为L_sight，双线传播中Lc_j为L_two_ray，Pt_j 为干扰机的干扰功率数值
Prj = lambda Pt_j, Gtr, Lc_j: Pt_j + Gtr - Lc_j - 1


def calculate_azimuth(x1, y1, x2, y2):  # 弧度值
    """计算水平方位角"""
    dx = x2 - x1
    dy = y2 - y1
    azimuth = np.arctan2(dy, dx)
    return round(azimuth, 4)


def calculate_elevation(x1, y1, z1, x2, y2, z2):
    """计算垂直俯仰角"""
    dx = x2 - x1
    dy = y2 - y1
    dz = z2 - z1
    distance_2d = np.sqrt(dx ** 2 + dy ** 2)
    elevation = np.arctan2(dz, distance_2d)
    return round(elevation, 4)


def calculate_received_power(jammer, comm_node):
    """计算通信节点在干扰机位置处的收信功率,真实"""
    jammer_type = jammer[1]
    communication_type = comm_node[1]
    distance = calculate_distance(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3], comm_node[4])

    if jammer_type == 0 and communication_type == 2:  # 地面通信节点对地面干扰机的影响
        interference_distance = Interference_distance[1]  # 双线传播的纳入计算的范围
        Gtr = 4.5
        h_t = 10
        h_r = 3
        loss = L_two_ray(distance, h_t, h_r)
    else:
        loss = L_sight(distance)
        interference_distance = Interference_distance[3]  # 视距传播的纳入计算的范围
        if communication_type == 2:  # 地面通信节点
            Gtr = 4.5
        else:  # 空中通信节点的影响
            Gtr = 4

    if interference_distance is not None and distance <= interference_distance:
        transmit_power_dBW = comm_node[6]
        # print('transmit_power_dBW',transmit_power_dBW)
        received_power = transmit_power_dBW + Gtr - loss - 1
    else:
        received_power = -1000  # 如果没有纳入计算的干扰距离，返回0值

    return received_power


def reverse_calculate_transmit_power1(jammer, comm_node, received_power):
    """根据干扰机位置的收信功率反向计算通信节点的发信功率,返回为dBw，包含底线估算，真算"""
    jammer_type = jammer[1]
    communication_type = comm_node[1]
    distance = calculate_distance(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3], comm_node[4])

    if jammer_type == 0 and communication_type == 2:  # 地面干扰机对地面通信节点的影响
        interference_distance = Interference_distance[1]  # 双线传播的纳入计算的范围
        Gtr = 4.5
        h_t = 10
        h_r = 3
        loss = L_two_ray(distance, h_t, h_r)
        Pmax = 13.98  # 最大通信发射功率
    else:
        loss = L_sight(distance)
        interference_distance = Interference_distance[3]  # 视距传播的纳入计算的范围
        if communication_type == 2:  # 空中干扰机对地面通信节点的影响
            Gtr = 4.5
            Pmax = 13.98  # 最大通信发射功率
        else:  # 干扰机对空中通信节点的影响
            Gtr = 4
            Pmax = 10  # 最大通信发射功率

    if interference_distance is not None and distance <= interference_distance:
        # 反向计算发信功率
        transmit_power_dBW = received_power - Gtr + loss + 1  # 假设干扰机的线缆损耗为1dB###########待公式
        if transmit_power_dBW > Pmax:  # 计算发信功率，估算中，不能超过最大发射功率
            transmit_power_dBW = Pmax
    else:
        transmit_power_dBW = -1000

    return round(transmit_power_dBW, 2)


def reverse_calculate_transmit_power2(jammer, comm_node, received_power):  # 接收干扰机、原来的发送干扰机、接收功率，计算原来的发送功率
    """根据干扰机位置的干扰信号收信功率反向计算干扰机的发信功率，不包含底线估算"""
    jammer_type = jammer[1]
    communication_type = comm_node[1]
    distance = calculate_distance(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3], comm_node[4])

    if jammer_type == 0 and communication_type == 0:  # 地面干扰机对地面干扰的影响
        interference_distance = Interference_distance[0]  # 双线传播的纳入计算的范围
        Gtr = 4
        h_t = 3
        h_r = 3
        loss = L_two_ray(distance, h_t, h_r)
    else:
        loss = L_sight(distance)
        interference_distance = Interference_distance[3]  # 视距传播的纳入计算的范围
        Gtr = 4

    if interference_distance is not None and distance <= interference_distance:
        # 反向计算发信功率
        transmit_power_dBW = received_power - Gtr + loss + 1  # 假设干扰机的线缆损耗为1dB###########待公式,说明
    else:
        transmit_power_dBW = -1000

    return round(transmit_power_dBW, 2)


def update_nodes_first(nodes_first, layout_result, single_jammer_weizhi_info, received_power_info):
    # 1. 复制interference_info，命名为estimate_interference_info,单个干扰机估计的，在它侦查范围内的通信节点相对于干扰机的位置信息和  发信功率、收信功率暂无
    estimate_interference_info = copy.deepcopy(single_jammer_weizhi_info)
    #print('estimate_interference_info 00',estimate_interference_info)
    #print('received_power_info',received_power_info)

    # 2. 拿received_power_info和estimate_interference_info对比，更新发信功率
    saved_jammer_info = estimate_interference_info

    jammer_id = saved_jammer_info[0]  # 在干扰机估计信息内，选择通信节点、干扰机的序号
    jammer = layout_result[jammer_id - 1]  # 当前侦查信号的干扰机信息，接收机
    detected_comm_nodes = set()

    noise = jammer[5] +3 # 干扰机的环境噪声功率，估计起始值  加3


    # 处理侦查到的信号
    for real_jammer_info in received_power_info:  # 在侦查信息中，选择通信节点、干扰机序号
        if real_jammer_info[0] == jammer_id:
            for j in range(1, len(real_jammer_info), 4):  #干扰机接收信息
                comm_node_id = real_jammer_info[j]
                azimuth = real_jammer_info[j + 1]
                elevation = real_jammer_info[j + 2]
                received_power = real_jammer_info[j + 3]

                for i in range(1, len(saved_jammer_info), 5):    #干扰机存储的信息single_jammer_weizhi_info
                    if saved_jammer_info[i] == comm_node_id and abs(
                            saved_jammer_info[i + 1] - azimuth) <= 0.004 and abs(
                            saved_jammer_info[i + 2] - elevation) <= 0.004:
                        if saved_jammer_info[i + 4] != 0:  # 如果是通信信号
                            detected_comm_nodes.add(comm_node_id)  # 记录侦查到的通信节点序号
                            comm_node = nodes_first[comm_node_id - 1]
                            transmit_power = reverse_calculate_transmit_power1(jammer, comm_node, received_power)
                            if transmit_power > 0:
                                # 在原有发信位置，设置发信功率
                                estimate_interference_info[i + 3] = transmit_power
                                # saved_jammer_info[i + 3] = transmit_power  #dBW
                                # print('saved_jammer_info[i + 3]',estimate_interference_info[jammer_id - 1][i + 3])


                            if len(received_power_info) == 1:  # 干扰机侦查到，只有一个通信收信的情况###################################################
                                distance = calculate_distance(nodes_first[comm_node_id - 1][2],nodes_first[comm_node_id - 1][3],
                                                              nodes_first[comm_node_id - 1][4], jammer[2], jammer[3], jammer[4])

                                dis1 = 0  # 范围档位
                                if saved_jammer_info[i + 1] == 2 and jammer[1] == 0:  # 地面通信节点，地面干扰机
                                    dd = Interference_decision[1][dis1]
                                elif saved_jammer_info[i + 1] == 1 and jammer[1] == 0:  # 空中通信节点，地面干扰机
                                    dd = Interference_decision[2][dis1]
                                else:  # 空中干扰机,针对空中、地面干扰机
                                    dd = Interference_decision[0][dis1]

                                if distance <= dd:  # 限定决策距离
                                    #print('单个通信发信节点，保守估计，将最大收信功率，设置在收信功率', comm_node_id)
                                    estimate_interference_info[i + 4] = com_max_receive[
                                        comm_node_id - 1]  # 保守估计，将最大收信功率，设置在收信功率  ,修正
                                    # print('',estimate_interference_info)



                        else:  # 如果是干扰信号
                            Trans = layout_result[comm_node_id - 1]  # 发送位置的干扰机信息
                            transmit_power = reverse_calculate_transmit_power2(jammer, Trans, received_power)
                            if transmit_power > 0:
                                # 在原有位置信息后添加发信功率
                                estimate_interference_info[i + 3] = transmit_power
                                # saved_jammer_info[i + 3] = transmit_power   #dBW







    # 2.处理未侦查到的通信节点,干扰机信号
    for i in range(1, len(saved_jammer_info), 5):
        #print('saved_jammer_info',saved_jammer_info)

        comm_node_id = saved_jammer_info[i]
        if comm_node_id not in detected_comm_nodes: # 未侦查到的通信节点
            if saved_jammer_info[i + 4] != 0:  # 如果是通信信号
                #print('comm_node_id',comm_node_id)
                distance = calculate_distance(nodes_first[comm_node_id-1][2], nodes_first[comm_node_id-1][3],
                                              nodes_first[comm_node_id-1][4],jammer[2], jammer[3], jammer[4])


                dis2 = 0 # 短距离的估计策略  会把远距离的通信信号，估计值偏大？or len(received_power_info) ==1
                if saved_jammer_info[i+1] == 2 and jammer[1] == 0:  # 地面通信节点，地面干扰机
                    dd = Interference_decision[1][dis2]
                elif saved_jammer_info[i+1] == 1 and jammer[1] == 0:  # 空中通信节点，地面干扰机
                    dd = Interference_decision[2][dis2]
                else:  # 空中干扰机,针对空中、地面干扰机
                    dd = Interference_decision[0][dis2]

                if distance <= dd:  #限定决策距离
                    #print('未侦查到的通信，距离过近，保守估计，将最大收信功率，设置在收信功率',comm_node_id)
                    estimate_interference_info[i + 4] = com_max_receive[comm_node_id - 1]  #保守估计，将最大收信功率，设置在收信功率  ,修正
                    #print('',estimate_interference_info)


                dis3 = 0  # 短距离的估计策略，将 环境噪声作为收信功率，估算通信节点的发信功率，并对收信功率，进行环境噪声最低值的估计
                if saved_jammer_info[i + 1] == 2 and jammer[1] == 0:  # 地面通信节点，地面干扰机
                    dd = Interference_decision[1][dis3]
                elif saved_jammer_info[i + 1] == 1 and jammer[1] == 0:  # 空中通信节点，地面干扰机
                    dd = Interference_decision[2][dis3]
                else:  # 空中干扰机,针对空中、地面干扰机
                    dd = Interference_decision[0][dis3]

                if distance <= dd:  # 限定决策距离,假设环境噪声临界值，为发信功率
                    comm_node = nodes_first[comm_node_id - 1]
                    transmit_power = reverse_calculate_transmit_power1(jammer, comm_node, noise)
                    # 在原有位置信息后添加发信功率
                    # print('假设的通信发射信号',transmit_power)  #设置在发信功率
                    estimate_interference_info[
                        i + 3] = transmit_power  # 假设，最坏的双线传播，视距传播，忽视了更小的“通信发信对干扰机”视距直传，导致预设的干扰机功率增大





    # 3. 遍历estimate_interference_info，计算最大收信功率并更新


    # 提取该干扰机侦查到的所有通信节点信息
    comm_nodes_info = []
    for i in range(1, len(saved_jammer_info), 5):  # 步长为5，因为每5个元素一组：通信节点序号、水平方位角、垂直方位角，通信节点发信功率，通信节点最大收信功率
        if len(saved_jammer_info) > i + 3:  # 确保有足够元素
            comm_node_id = saved_jammer_info[i]
            if comm_node_id <= 30:  #通信设备数量为30
                comm_node = nodes_first[comm_node_id - 1]
                transmit_power = estimate_interference_info[i + 3]  # 通信节点的发信功率，dBW   ，估算值
                if saved_jammer_info[i + 4] != 0:  # 排除侦查获得的干扰信号的干扰机
                    comm_nodes_info.append((comm_node, transmit_power))


    # 计算每个通信节点的最大收信功率
    for index, (comm_node, _) in enumerate(comm_nodes_info):
        #print('',index, (comm_node, _), )
        # 初始化最大收信功率为一个较小的值，例如-1000

        #estimate_interference_info[1 + index * 5 + 4] = -1000  # 估算的最大收信功率小于通信节点的环境噪声

        max_received_power = -1000  # 初始化最大收信功率为一个较小的值，例如-1000

        for other_comm_node, other_transmit_power in comm_nodes_info:
            if other_comm_node[0] != comm_node[0]:
                distance = calculate_distance(comm_node[2], comm_node[3], comm_node[4],
                                              other_comm_node[2], other_comm_node[3], other_comm_node[4])
                if comm_node[1] == 2 and other_comm_node[1] == 2:
                    Gtr = 5
                    Lc_j = L_two_ray(distance, 10, 10)  # 地面通信节点的天线高度为8m
                elif comm_node[1] == 1 and other_comm_node[1] == 1:
                    Lc_j = L_sight(distance)
                    Gtr = 4
                else:
                    Lc_j = L_sight(distance)
                    Gtr = 4.5

                if other_transmit_power > 0:  # dBW
                    received_power = other_transmit_power + Gtr - Lc_j - 1
                    received_power = round(received_power, 2)
                    if received_power > max_received_power:
                        max_received_power = received_power

                        if (comm_node[1] == 2 and max_received_power > -93) or (comm_node[1] == 1 and max_received_power > -103):  # 通信节点的环境噪声和通信信号的预估保守临界值，-93dBm，-103dBm
                            # 更新最大收信功率到对应位置，否则保持原值
                            estimate_interference_info[1 + index * 5 + 4] = max_received_power
                            # print('estimate_interference_info[jammer_id - 1][1 + index * 5 + 4]',max_received_power)




        #print('other_transmit_power',_)
        if _ > 9 and (estimate_interference_info[1 + index * 5 + 4]  == -1000 or estimate_interference_info[1 + index * 5 + 4]  == 0):
            dis4 = 0  # 临近大功率通信发信节点的，补充策略
            distance = calculate_distance(comm_node[2], comm_node[3], comm_node[4], jammer[2], jammer[3], jammer[4])
            if comm_node[1] == 2 and jammer[1] == 0:  # 地面通信节点，地面干扰机
                dd = Interference_decision[1][dis4]
            elif comm_node[1] == 1 and jammer[1] == 0:  # 空中通信节点，地面干扰机
                dd = Interference_decision[2][dis4]
            else:  # 空中干扰机,针对空中、地面干扰机
                dd = Interference_decision[0][dis4]

            if distance <= dd:  # 限定决策距离,临近大功率通信发信节点的，补充策略

                #print('临近大功率通信发信节点的，补充策略',comm_node[0])
                if comm_node[1] == 2 and jammer[1] == 0 or (comm_node[1] == 1 and jammer[1] == 1):  # （地面通信节点，地面干扰机）或者 （空中通信节点，空中干扰机）
                    estimate_interference_info[1 + index * 5 + 4]  = jammer[5] + 10  # 干扰机的环境噪声，通信节点的
                elif comm_node[1] == 1 and jammer[1] == 0:  # （空中通信节点，地面干扰机）
                    estimate_interference_info[1 + index * 5 + 4]  = jammer[5] + 14
                else:  # （空中干扰机，地面通信节点）
                    estimate_interference_info[1 + index * 5 + 4]  = jammer[5] + 13  # 干扰机的环境噪声，通信节点的

    return estimate_interference_info


def generate_received_power_info(nodes_first, layout_result,single_jammer):
    # 产生通信节点,干扰机， 在干扰机位置处的收信功率信息，真实环境的模拟值,接收一定限度的噪声
    result = []

    jammer = single_jammer
    jammer_id = jammer[0]
    current_jammer_info = [jammer_id]
    noise = jammer[5] + 6
    for comm_node in nodes_first:
        comm_id = comm_node[0]
        received_power = calculate_received_power(jammer, comm_node)  # dBW
        # 获取环境噪声，增加识别限度
        # print('received_power',received_power)

        if received_power > noise:
            # 再增方位角和俯仰角
            azimuth = calculate_azimuth(jammer[2], jammer[3], comm_node[2], comm_node[3])
            elevation = calculate_elevation(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3],
                                            comm_node[4])
            # print('received_power',received_power)
            current_jammer_info.extend([comm_id, azimuth, elevation, round(received_power, 2)])
            # print('current_jammer_info',current_jammer_info)

    # 模拟接收干扰信号
    for jammer2 in layout_result:
        trans_jammer_id = jammer2[0]
        # 排除自身干扰,且干扰机具有发信功率
        if trans_jammer_id != jammer_id and len(jammer2) > 6 and jammer2[6] > 0:

            interference_power = calculate_interference_power2(jammer2, jammer, jammer2[6])  # 干扰机，对干扰机的 噪声接收功率
            if interference_power > noise:
                # 再增干扰信号的方位角和俯仰角
                interference_azimuth = calculate_azimuth(jammer[2], jammer[3], jammer2[2], jammer2[3])
                interference_elevation = calculate_elevation(jammer[2], jammer[3], jammer[4], jammer2[2], jammer2[3],
                                                             jammer2[4], )
                current_jammer_info.extend(
                    [trans_jammer_id, interference_azimuth, interference_elevation, round(interference_power, 2)])

    if len(current_jammer_info) > 1:
        result.append(current_jammer_info)

    return result


def calculate_distance(x1, y1, z1, x2, y2, z2):
    """计算三维欧氏距离"""
    return np.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2 + (z1 - z2) ** 2) / 1000


def calculate_interference_power2(jammer, comm_node, total_power):
    """计算单个干扰机在单个干扰机处造成的干扰功率，不含环境噪声"""
    jammer_type = jammer[1]
    communication_type = comm_node[1]
    distance = calculate_distance(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3], comm_node[4])

    if jammer_type == 0 and communication_type == 0:  # 地面干扰机对地面干扰机的影响
        interference_distance = Interference_distance[1]  # 双线传播的纳入计算的范围
        Gtr = 4
        h_t = 3
        h_r = 3
        loss = L_two_ray(distance, h_t, h_r)
    else:
        loss = L_sight(distance)
        interference_distance = Interference_distance[3]  # 视距传播的纳入计算的范围
        Gtr = 4

    if interference_distance is not None and distance <= interference_distance:
        # 计算所有与通信节点同频段的功放的功率之和
        total_power = total_power
        # 计算干扰功率，通信节点的线缆损耗为1dB
        interference_power = total_power + Gtr - loss - 1
    else:
        interference_power = -1000  # 如果没有纳入计算的干扰距离，返回0值

    return interference_power


def calculate_interference_power(jammer, comm_node, total_power):
    """计算单个干扰机在单个通信节点处造成的干扰功率，不含环境噪声"""
    jammer_type = jammer[1]
    communication_type = comm_node[1]
    distance = calculate_distance(jammer[2], jammer[3], jammer[4], comm_node[2], comm_node[3], comm_node[4])

    if jammer_type == 0 and communication_type == 2:  # 地面干扰机对地面通信节点的影响
        interference_distance = Interference_distance[1]  # 双线传播的纳入计算的范围
        Gtr = 4.5
        h_t = 3
        h_r = 10
        loss = L_two_ray(distance, h_t, h_r)
    else:
        loss = L_sight(distance)
        interference_distance = Interference_distance[3]  # 视距传播的纳入计算的范围
        if communication_type == 2:  # 空中干扰机对地面通信节点的影响
            Gtr = 4.5
        else:  # 干扰机对空中通信节点的影响
            Gtr = 4

    if interference_distance is not None and distance <= interference_distance:
        # 计算干扰功率，通信节点的线缆损耗为1dB
        interference_power = total_power + Gtr - loss - 1
    else:
        interference_power = -1000  # 如果没有纳入计算的干扰距离，返回0值

    return interference_power


def allocate_interference_power(estimate_info, layout_result, nodes_first,dis):
    """
    通信节点为多个节点，干扰机为一个节点，
    分配干扰功率到干扰机的功放中，设置功率。
    """
    jammer_id = estimate_info[0]
    jammer = layout_result[jammer_id - 1]
    max_required_power = 0

    #print('estimate_info',estimate_info)

    # 1. 遍历通信节点，计算这些通信节点成功干扰所需的干扰功率
    for i in range(1, len(estimate_info), 5):
        this_jammer_required = 0  # 初始化,这个干扰机对这个通信节点的干扰功率
        if len(estimate_info) > i + 6:
            if estimate_info[i + 4] != 0:  # 排除干扰信号
                comm_node_id = estimate_info[i]
                comm_node = nodes_first[comm_node_id - 1]

                distance = calculate_distance(comm_node[2], comm_node[3], comm_node[4], jammer[2], jammer[3], jammer[4])

                if comm_node[1] == 2 and jammer[1] == 0:  # 地面通信节点，地面干扰机
                    dd = Interference_decision[1][dis]
                elif comm_node[1] == 1 and jammer[1] == 0:  # 空中通信节点，地面干扰机
                    dd = Interference_decision[2][dis]
                else:  # 空中干扰机,针对空中、地面干扰机
                    dd = Interference_decision[0][dis]

                if distance > dd:
                    pass
                else:
                    if estimate_info[i + 4] < -105:  # 空中通信节点的接收的通信信号小于环境噪声  临界值
                        pass
                    elif estimate_info[i + 2] == 0 and estimate_info[i + 4] < -95:  # 地面通信节点的接收的通信信号小于环境噪声  临界值
                        pass
                    else:
                        total_required_power = estimate_info[i + 4] + 4.775  # 3倍干信比，为4.77dB，dBW
                        #print('total_required_power',total_required_power)

                        total_other_jammers_interference = 0  # 其他干扰机对该通信节点的干扰功率，初始化

                        # 2.遍历其它干扰机，计算其它干扰机对这些通信节点施加的干扰
                        for j in range(1, len(estimate_info), 5):
                            if estimate_info[j + 4] == 0:  # 选择干扰机

                                other_jammer_id = estimate_info[j]
                                other_jammer = layout_result[other_jammer_id - 1]
                                other_jammer_power = estimate_info[j + 3]  # dBW
                                if other_jammer_power > 0:
                                    interference_power = calculate_interference_power(other_jammer, comm_node,other_jammer_power)  # dBW
                                    #print('interference_power:',interference_power)
                                    total_other_jammers_interference += 10 ** (interference_power / 10)  # 转换为watts

                        # 3. 计算这个干扰机所需要释放的干扰功率w
                        this_comm_required_power = 10 ** (total_required_power / 10) - total_other_jammers_interference

                        # 检查 this_comm_required_power 是否为正数
                        if this_comm_required_power > 0:

                            if comm_node[1] == 2 and jammer[1] == 0:
                                Gtr = 4.5
                                Lc_j = L_two_ray(distance, 3, 10)  # 地面通信节点的天线高度为8m
                            elif comm_node[1] == 1:
                                Lc_j = L_sight(distance)
                                Gtr = 4
                            else:
                                Lc_j = L_sight(distance)
                                Gtr = 4.5

                            # 将 this_comm_required_power 从瓦特转换为分贝瓦
                            this_comm_dBW = 10 * math.log10(this_comm_required_power)
                            this_jammer_required = this_comm_dBW - Gtr + Lc_j + 1
                        else:
                            pass


        # 选择所需这个干扰机功率的最大值
        if this_jammer_required > max_required_power:
            max_required_power = this_jammer_required

    #old_power = layout_result[jammer_id - 1][6]
    #if max_required_power > old_power :  #干扰机发信功率设置，不能下降  半倍下调
    if max_required_power > 0:

        if jammer[1] == 0:  # 地面干扰机
            max_required_power = min(max_required_power, 16)  # 地面干扰机最大功率为40w
        else:  # 空中干扰机
            max_required_power = min(max_required_power, 13)  # 空中干扰机最大功率为20W


        #print('max_required_power:',max_required_power)
        # 可增加备注，知晓干扰机能量耗尽
        max_required_power_w = 10 ** (max_required_power / 10)  # 将dBW转换为W

        if 0.025 * (4 + max_required_power_w) / (0.95 * 24) < jammer[7]:  # 如果干扰机剩余能量支持这个功率 4w为干扰机杂项功率
            layout_result[jammer_id - 1][6] = round(max_required_power, 2)  # dBW# 将最大值放入layout中干扰功率的位置
        elif jammer[7] > 0:
            max_required_power_w = (jammer[7] * 0.95 * 24) / 0.025 - 4  # 计算最大可分配功率
            if max_required_power_w > 0:
                max_required_power = 10 * math.log10(max_required_power_w)  # 转换为dBW
                layout_result[jammer_id - 1][6] = round(max_required_power, 2)
            else:
                layout_result[jammer_id - 1][6] = 0  # 如果没有剩余能量，设置功率为0
        else:
            layout_result[jammer_id - 1][6] = 0  # 如果没有剩余能量，设置功率为0



    return layout_result


# 示例：加载并打印数据
def main_jammer_run():
    layout_result, nodes_first = load_layout_result()
    # print("layout_result:", layout_result)

    #print("communication:", nodes_first)

    interference_info = load_interference_info()  # 读取干扰机存储的通信节点方位信息，未区分距离间隔
    #print("干扰机与通信节点的位置方位信息：", interference_info)

    # 记录干扰资源调度算法程序开始时间
    start_time = time.time()
    Number_Jam = len(layout_result)


    # 生成一个包含 0 到 Number_Jam - 1 的随机排列序列
    random_jammer_order = list(range(Number_Jam))
    random.shuffle(random_jammer_order)
    #print('random_jammer_order', random_jammer_order)

    guji = []
    # 按照随机顺序逐个处理每个干扰机
    for random_index in random_jammer_order:
        #print('random_index',random_index)

        jammer_id = random_index

        # 仿真获取当前干扰机位置处的通信节点收信功率信息，模拟真实环境
        single_jammer_layout_result = layout_result[jammer_id]
        #print('single_jammer_layout_result', single_jammer_layout_result)
        received_power_info = generate_received_power_info(nodes_first, layout_result,
                                                           single_jammer_layout_result)
        #print('received_power_info', received_power_info)

        # 依据当前干扰机侦查信息、nodes_first列表，估算通信节点的发信功率，包括周边干扰机的发信功率
        single_jammer_weizhi_info = interference_info[jammer_id]
        # print('single_jammer_weizhi_info', single_jammer_weizhi_info)
        estimate_interference_info = update_nodes_first(nodes_first, layout_result,
                                                        single_jammer_weizhi_info, received_power_info)
        #print('estimate_interference_info', estimate_interference_info)

        guji.append(estimate_interference_info)

    #print('guji',guji)    # 每个干扰机的估计信息，不健全

    for dis in range(9):
        if dis == 3:
            break
        else:
            # 按照随机顺序逐个处理每个干扰机
            for estimate_interference_info in guji:
                #print('xxxxxxxxxxxxxxxxxx  estimate_interference_info',estimate_interference_info)
                # 基于当前干扰机侦查的信息，调度当前干扰机，为具有收信功能的通信节点分配干扰功率
                layout_result = allocate_interference_power(estimate_interference_info, layout_result, nodes_first, dis)
                #print('single_jammer_layout_result',dis,single_jammer_layout_result)



    # 计算干扰机的剩余能量
    air_time = land_time = 0.025  # 干扰机工作时间（小时），1.5分钟
    efficiency = 0.95  # 能量转换效率,正常干扰的电量使用上限

    # 遍历 layout_result，计算每个干扰机的剩余能量
    for row in layout_result:

        if row[1] == 0:  # 地面干扰机
            P_landtotal = round(10 ** (row[6] / 10), 2)  #
            land_energy = land_time * (4 + P_landtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 8:  # 如果第8列不存在，则扩展列表:
                row.append(0)
                land_energy_initial = row[7]  # 地面干扰机，上次运行后，剩余的能量（单位：Ah）
            else:
                if row[7] > 0:
                    land_energy_initial = row[7]  # 地面干扰机初始剩余能量（单位：Ah）
                else:
                    print(f"第{row[0]}行的剩余能量值无效：{row[7]}")
                    break
            land_energy_remain = land_energy_initial - land_energy  # 计算剩余能量
            row[7] = round(land_energy_remain, 3)  # 将剩余能量存储在第7列
        elif row[1] == 1:  # 空中干扰机
            P_airtotal = round(10 ** (row[6] / 10), 2)  # 空中干扰机的功率
            air_energy = air_time * (4 + P_airtotal) / (efficiency * 24)  # 计算能量消耗
            if len(row) < 8:  # 如果第8列不存在，则扩展列表:
                row.append(0)
                air_energy_initial = row[7]  # 空中干扰机上次运行后，剩余的能量（单位：Ah）
            else:
                if row[7] > 0:
                    air_energy_initial = row[7]  # 空中干扰机上次运行后，剩余的能量（单位：Ah）
                else:
                    print(f"第{row[0]}行的剩余能量值无效：{row[7]}")
                    break
            air_energy_remain = air_energy_initial - air_energy  # 计算剩余能量
            if air_energy_remain < 0 :
                air_energy_remain = 0  # 剩余能量小于0，设置为0，取消计算的误差，使用0.95性能要求外的，小量电量
            row[7] = round(air_energy_remain, 3)  # 将剩余能量存储在第7列

    #print("更新后的 layout_result（包含剩余能量）：", layout_result)

    # 保存更新后的 layout_result
    save_layout_result(layout_result)

    # 记录程序结束时间
    end_time = time.time()
    # 计算程序运行时长
    elapsed_time = end_time - start_time

    return layout_result, elapsed_time


if __name__ == "__main__":
    layout_result, elapsed_time = main_jammer_run()
    print(f"程序运行时长: {elapsed_time} 秒")
