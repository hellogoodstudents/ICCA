import numpy as np

# 定义 Prj 的值
Prj_values = [-95, -90, -85]

# 针对地面通信目标 - 空中干扰机
def d_ground_air(Prj):
    return 10 ** ((-Prj - 12.97 - 20 * np.log10(600)) / 30)

# 针对地面通信目标 - 地面干扰机
def d_ground_ground(Prj):
    return 10 ** ((-Prj - 97.46 + 20 * np.log10(3) + 20 * np.log10(8)) / 30)

# 针对空中通信目标 - 空中干扰机
def d_air_air(Prj):
    return 10 ** ((-Prj - 12.97 - 20 * np.log10(600)) / 30)

# 针对空中通信目标 - 地面干扰机
def d_air_ground(Prj):
    return 10 ** ((-Prj - 9.96 - 20 * np.log10(600)) / 30)

# 计算不同 Prj 值下的 d 值
print("针对地面通信目标 - 空中干扰机：")
for Prj in Prj_values:
    print(f"Prj = {Prj} dB 时，d = {d_ground_air(Prj)}")

print("\n针对地面通信目标 - 地面干扰机：")
for Prj in Prj_values:
    print(f"Prj = {Prj} dB 时，d = {d_ground_ground(Prj)}")

print("\n针对空中通信目标 - 空中干扰机：")
for Prj in Prj_values:
    print(f"Prj = {Prj} dB 时，d = {d_air_air(Prj)}")

print("\n针对空中通信目标 - 地面干扰机：")
for Prj in Prj_values:
    print(f"Prj = {Prj} dB 时，d = {d_air_ground(Prj)}")